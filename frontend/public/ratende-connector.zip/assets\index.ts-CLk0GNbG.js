chrome.runtime.onMessageExternal.addListener((r,n,e)=>(r==null?void 0:r.type)==="ping"?(e({ok:!0,version:chrome.runtime.getManifest().version}),!0):!1);
